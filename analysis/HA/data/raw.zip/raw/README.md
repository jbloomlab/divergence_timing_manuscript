# Raw Influenza HA data

I downloaded these sequence from the Influenza Virus Resource Database June 2017.
They are all IAV sequences and I did not specify a region or a host. 
